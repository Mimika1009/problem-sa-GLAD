#include <iostream>


#include<GLFW/glfw3.h>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
